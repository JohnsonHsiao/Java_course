package edu.neu.mgen;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "It is my first Java program" );
        // This is a single-line comment in Java.
    }
}
/*
 This is a multi-line comment in Java.
 It can span multiple lines.
 Use this for longer explanations or block comments.
*/
